update servers set server_autostart= :server_autostart: where server_id=:server_id:;
