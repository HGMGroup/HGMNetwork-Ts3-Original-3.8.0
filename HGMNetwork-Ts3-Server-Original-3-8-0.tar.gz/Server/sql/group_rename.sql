update :table: set name=:name: where group_id=:group_id:
