select * from clients where client_login_name like :pattern: limit :start:, :duration:;
